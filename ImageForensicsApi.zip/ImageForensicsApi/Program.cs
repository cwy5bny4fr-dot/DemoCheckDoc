using Microsoft.AspNetCore.Http.Features;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;

var builder = WebApplication.CreateBuilder(args);

// Allow reasonably large uploads (scanned docs / photos)
builder.Services.Configure<FormOptions>(o =>
{
    o.MultipartBodyLengthLimit = 50_000_000; // 50 MB
});

builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

var app = builder.Build();

app.UseCors();
app.UseDefaultFiles();   // serves wwwroot/index.html at "/"
app.UseStaticFiles();

// ---------------------------------------------------------------------
// GET / -> service info (also see wwwroot/index.html for a test UI)
// ---------------------------------------------------------------------
app.MapGet("/api/info", () => Results.Ok(new
{
    service = "Image Forensics API",
    endpoints = new[]
    {
        "POST /api/ela            (form: file, quality=1-100 default 90, scale=1-50 default 15) -> PNG",
        "POST /api/compare        (form: fileA, fileB, threshold=0-255 default 25) -> PNG (diff highlighted in red)",
        "POST /api/compare/json   (form: fileA, fileB, threshold=0-255 default 25) -> JSON stats only"
    }
}));

// ---------------------------------------------------------------------
// POST /api/ela  — Error Level Analysis on a single image
// Re-saves the image as JPEG at a given quality and visualizes the
// per-pixel difference. Areas that were pasted/edited in later tend to
// stand out with a different error level than the rest of the image.
// ---------------------------------------------------------------------
app.MapPost("/api/ela", async (HttpRequest request) =>
{
    if (!request.HasFormContentType) return Results.BadRequest(new { error = "multipart/form-data required" });
    var form = await request.ReadFormAsync();
    var file = form.Files["file"];
    if (file is null || file.Length == 0) return Results.BadRequest(new { error = "missing form field 'file'" });

    int quality = int.TryParse(form["quality"], out var q) ? Math.Clamp(q, 1, 100) : 90;
    int scale = int.TryParse(form["scale"], out var s) ? Math.Clamp(s, 1, 50) : 15;

    using var srcStream = file.OpenReadStream();
    using var original = await Image.LoadAsync<Rgba32>(srcStream);

    using var jpegMs = new MemoryStream();
    await original.SaveAsJpegAsync(jpegMs, new JpegEncoder { Quality = quality });
    jpegMs.Position = 0;
    using var resaved = await Image.LoadAsync<Rgba32>(jpegMs);

    using var ela = new Image<Rgba32>(original.Width, original.Height);

    for (int y = 0; y < original.Height; y++)
    {
        for (int x = 0; x < original.Width; x++)
        {
            var a = original[x, y];
            var b = resaved[x, y];
            byte r = (byte)Math.Clamp(Math.Abs(a.R - b.R) * scale, 0, 255);
            byte g = (byte)Math.Clamp(Math.Abs(a.G - b.G) * scale, 0, 255);
            byte bl = (byte)Math.Clamp(Math.Abs(a.B - b.B) * scale, 0, 255);
            ela[x, y] = new Rgba32(r, g, bl, 255);
        }
    }

    var outMs = new MemoryStream();
    await ela.SaveAsPngAsync(outMs, new PngEncoder());
    outMs.Position = 0;
    return Results.File(outMs.ToArray(), "image/png", "ela_result.png");
});

// ---------------------------------------------------------------------
// Shared diff computation used by both /api/compare and /api/compare/json
// ---------------------------------------------------------------------
static (Image<Rgba32> highlighted, int diffPixels, int totalPixels, byte maxDiff, (int x, int y, int w, int h)? bbox)
    ComputeDiff(Image<Rgba32> a, Image<Rgba32> b, byte threshold)
{
    int width = Math.Min(a.Width, b.Width);
    int height = Math.Min(a.Height, b.Height);

    var highlighted = a.Clone(ctx => ctx.Resize(width, height));
    using var bResized = b.Clone(ctx => ctx.Resize(width, height));

    int diffPixels = 0;
    byte maxDiff = 0;
    int minX = int.MaxValue, minY = int.MaxValue, maxX = -1, maxY = -1;

    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            var pa = highlighted[x, y];
            var pb = bResized[x, y];
            int dr = Math.Abs(pa.R - pb.R);
            int dg = Math.Abs(pa.G - pb.G);
            int db = Math.Abs(pa.B - pb.B);
            byte diff = (byte)((dr + dg + db) / 3);
            if (diff > maxDiff) maxDiff = diff;

            if (diff >= threshold)
            {
                diffPixels++;
                if (x < minX) minX = x;
                if (y < minY) minY = y;
                if (x > maxX) maxX = x;
                if (y > maxY) maxY = y;

                // Highlight differing pixel in solid red, keep rest of image as-is
                highlighted[x, y] = new Rgba32(255, 0, 0, 255);
            }
            else
            {
                // Dim unchanged areas slightly so the red highlight stands out
                highlighted[x, y] = new Rgba32(
                    (byte)(pa.R / 1.5), (byte)(pa.G / 1.5), (byte)(pa.B / 1.5), 255);
            }
        }
    }

    (int, int, int, int)? bbox = diffPixels > 0
        ? (minX, minY, maxX - minX + 1, maxY - minY + 1)
        : null;

    return (highlighted, diffPixels, width * height, maxDiff, bbox);
}

// ---------------------------------------------------------------------
// POST /api/compare — returns a PNG with differing regions highlighted in red
// ---------------------------------------------------------------------
app.MapPost("/api/compare", async (HttpRequest request) =>
{
    if (!request.HasFormContentType) return Results.BadRequest(new { error = "multipart/form-data required" });
    var form = await request.ReadFormAsync();
    var fileA = form.Files["fileA"];
    var fileB = form.Files["fileB"];
    if (fileA is null || fileB is null) return Results.BadRequest(new { error = "missing 'fileA' and/or 'fileB'" });

    byte threshold = byte.TryParse(form["threshold"], out var t) ? t : (byte)25;

    using var streamA = fileA.OpenReadStream();
    using var streamB = fileB.OpenReadStream();
    using var imgA = await Image.LoadAsync<Rgba32>(streamA);
    using var imgB = await Image.LoadAsync<Rgba32>(streamB);

    var (highlighted, diffPixels, totalPixels, maxDiff, bbox) = ComputeDiff(imgA, imgB, threshold);
    using (highlighted)
    {
        var outMs = new MemoryStream();
        await highlighted.SaveAsPngAsync(outMs, new PngEncoder());
        outMs.Position = 0;

        double pct = totalPixels == 0 ? 0 : 100.0 * diffPixels / totalPixels;
        var result = Results.File(outMs.ToArray(), "image/png", "diff_highlighted.png");

        // Surface key stats as response headers since the body is the image
        request.HttpContext.Response.Headers["X-Diff-Pixel-Count"] = diffPixels.ToString();
        request.HttpContext.Response.Headers["X-Diff-Percentage"] = pct.ToString("F3");
        request.HttpContext.Response.Headers["X-Max-Pixel-Diff"] = maxDiff.ToString();
        if (bbox is { } box)
        {
            request.HttpContext.Response.Headers["X-Diff-BBox"] = $"{box.x},{box.y},{box.w},{box.h}";
        }
        return result;
    }
});

// ---------------------------------------------------------------------
// POST /api/compare/json — same comparison, JSON stats only (no image)
// ---------------------------------------------------------------------
app.MapPost("/api/compare/json", async (HttpRequest request) =>
{
    if (!request.HasFormContentType) return Results.BadRequest(new { error = "multipart/form-data required" });
    var form = await request.ReadFormAsync();
    var fileA = form.Files["fileA"];
    var fileB = form.Files["fileB"];
    if (fileA is null || fileB is null) return Results.BadRequest(new { error = "missing 'fileA' and/or 'fileB'" });

    byte threshold = byte.TryParse(form["threshold"], out var t) ? t : (byte)25;

    using var streamA = fileA.OpenReadStream();
    using var streamB = fileB.OpenReadStream();
    using var imgA = await Image.LoadAsync<Rgba32>(streamA);
    using var imgB = await Image.LoadAsync<Rgba32>(streamB);

    var (highlighted, diffPixels, totalPixels, maxDiff, bbox) = ComputeDiff(imgA, imgB, threshold);
    highlighted.Dispose();

    double pct = totalPixels == 0 ? 0 : 100.0 * diffPixels / totalPixels;

    return Results.Ok(new
    {
        diffPixelCount = diffPixels,
        totalPixels,
        diffPercentage = Math.Round(pct, 3),
        maxPixelDiff = maxDiff,
        likelyEdited = pct > 0.5, // heuristic: adjust to taste
        boundingBox = bbox is { } b
            ? new { x = b.x, y = b.y, width = b.w, height = b.h }
            : null
    });
});

app.Run();
