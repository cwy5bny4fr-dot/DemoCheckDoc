# Image Forensics API

ASP.NET Core Minimal API (.NET 8) สำหรับตรวจสอบภาพ/เอกสารที่อาจถูกแก้ไข
ใช้ [SixLabors.ImageSharp](https://github.com/SixLabors/ImageSharp) เท่านั้น — ไม่ต้องพึ่ง native library ใด ๆ รันได้ทั้ง Windows/Linux/Mac

## รันโปรเจกต์

```bash
cd ImageForensicsApi
dotnet restore
dotnet run
```

จากนั้นเปิด `http://localhost:5000` (หรือพอร์ตที่ dotnet แจ้ง) จะเจอหน้าเว็บทดสอบง่าย ๆ
หรือเรียก API ตรง ๆ ผ่าน curl/Postman ก็ได้

## Endpoints

### `POST /api/ela`
Error Level Analysis — หาจุดที่ถูกแก้ไข/แปะทับในภาพเดียว โดยบันทึกภาพเป็น JPEG คุณภาพต่ำซ้ำแล้วเทียบผลต่างพิกเซล พื้นที่ที่สว่างผิดปกติ = จุดต้องสงสัย

```bash
curl -X POST http://localhost:5000/api/ela \
  -F "file=@payslip.png" \
  -F "quality=90" \
  -F "scale=15" \
  -o ela_result.png
```

| field   | ค่าเริ่มต้น | คำอธิบาย                                   |
|---------|------------|---------------------------------------------|
| file    | -          | ไฟล์ภาพ (บังคับ)                            |
| quality | 90         | คุณภาพ JPEG ที่ใช้บันทึกซ้ำ (1-100)         |
| scale   | 15         | ตัวคูณขยายความต่างให้เห็นชัด (1-50)         |

### `POST /api/compare`
เทียบภาพ 2 ไฟล์ (เช่น สลิป 2 เวอร์ชัน) คืนภาพที่ไฮไลต์จุดต่างเป็นสีแดง พร้อมสถิติใน response header

```bash
curl -X POST http://localhost:5000/api/compare \
  -F "fileA=@version1.png" \
  -F "fileB=@version2.png" \
  -F "threshold=25" \
  -o diff.png -D headers.txt
```

Response headers: `X-Diff-Pixel-Count`, `X-Diff-Percentage`, `X-Max-Pixel-Diff`, `X-Diff-BBox`

### `POST /api/compare/json`
เหมือน `/api/compare` แต่คืนเฉพาะ JSON สถิติ ไม่มีรูปภาพ — เหมาะกับใช้ในระบบอัตโนมัติ

```bash
curl -X POST http://localhost:5000/api/compare/json \
  -F "fileA=@version1.png" \
  -F "fileB=@version2.png"
```

```json
{
  "diffPixelCount": 4213,
  "totalPixels": 512000,
  "diffPercentage": 0.823,
  "maxPixelDiff": 255,
  "likelyEdited": true,
  "boundingBox": { "x": 210, "y": 340, "width": 180, "height": 40 }
}
```

## หมายเหตุ

- ถ้าไฟล์ต้นทางเป็น PDF ให้แปลงเป็นรูปภาพ (PNG) ก่อนส่งเข้า API เช่นด้วย `pdftoppm` หรือ ImageMagick
- `/api/compare` เหมาะมากกับกรณีที่มีเอกสาร "เวอร์ชันก่อน/หลัง" ให้เทียบ (เช่น สลิปเงินเดือน 2 ไฟล์ที่สงสัยว่าถูกแก้ตัวเลข) — จุดที่ตัวเลขถูกเปลี่ยนจะติดสีแดงชัดเจน
- ปรับ `threshold` ให้เหมาะกับคุณภาพ/สัญญาณรบกวนของภาพ (ภาพสแกนคุณภาพต่ำอาจต้องตั้ง threshold สูงขึ้นเพื่อลด false positive)
- โค้ดนี้ยังไม่ได้ผ่านการ `dotnet build` จริง (สภาพแวดล้อมที่เขียนโค้ดนี้ไม่มีอินเทอร์เน็ตให้ restore NuGet) — โปรดรัน `dotnet restore && dotnet build` ก่อนใช้งานจริง และแจ้งกลับได้หากเจอ error จะแก้ให้
